import sanityClient from '@sanity/client'
const options = {
    projectId: "j6hvvg4b",
    dataset: "production"
}

import {teamMember} from './teamMember'
import {Logg} from './Logg'

export const schemaTypes = [teamMember, Logg]
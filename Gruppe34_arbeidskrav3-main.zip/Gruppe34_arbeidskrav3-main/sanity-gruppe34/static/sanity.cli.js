import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'j6hvvg4b',
    dataset: 'production'
  },
  autoUpdates: true,
})